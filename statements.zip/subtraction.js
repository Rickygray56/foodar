var x = 3;

var y = 7;

var z = x - y;

console.log("Result:" + z);