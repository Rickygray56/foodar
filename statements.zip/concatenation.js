var firstName = "Ricky";

var lastName = "Gray";

console.log(firstName + " " + lastName);