var m = -10;

if(m == 10) {
    console.log("The value of m is equal to 10");
} else if(m < 0 && m % 10 == 0) {
    console.log("The value is less than zero and it is even");
} else {
    console.log("the value of m is something else");
}